const express = require('express');
const router = express.Router();

router.post('/login', (req, res) => {
    const { username, password } = req.body;
    // Example: Hardcoded username and password
    if (username === 'admin' && password === 'password123') {
        res.json({ message: 'Login successful', user: username });
    } else {
        res.status(401).json({ error: 'Invalid credentials' });
    }
});

module.exports = router;
