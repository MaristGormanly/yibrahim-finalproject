const express = require('express');
const router = express.Router();
const db = require('../db/db'); // Ensure this path is correct to your database connection file

router.get('/', async (req, res) => {
    try {
        const { rows } = await db.query('SELECT * FROM users');
        res.json(rows);
    } catch (err) {
        console.error('Database query failed:', err);
        res.status(500).send('Internal Server Error');
    }
});

module.exports = router;
