const express = require('express');
const path = require('path');
const app = express();

// Import routers
const indexRouter = require('./routes/index');
const usersRouter = require('./routes/users');
const authRouter = require('./routes/auth');

// Middleware to parse JSON for the incoming request
app.use(express.json());

// Serve static files from the 'public' directory inside the 'client' folder
app.use(express.static(path.join(__dirname, '..', 'client', 'public')));

// Use routers
app.use('/', indexRouter);
app.use('/users', usersRouter);
app.use('/auth', authRouter);

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`);
});
